const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');
const {Button , ActionRow} = require('devland.js');
module.exports = {
    name: "ticket",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message) => {
        if (client.config.buyers.includes(message.authorId)){
            message.delete();
            let ticketb = new Button();
            ticketb.customId = 'tickets',
            ticketb.emoji = '📧',
            ticketb.style = 1

            const row = new ActionRow(ticketb);

            let embed = new Discord.Embed();
            embed.description = `**Pour ouvrir un Ticket cliquez sur le bouton ci-dessous**`,
            embed.color = client.config.default_color,
            embed.footer = client.config.footer

            message.channel.send({embeds: [embed], components: [row]})
        }
    }
}
