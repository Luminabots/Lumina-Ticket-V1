const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');
const {parseEmoji , Embed } = require("devland.js")
module.exports = {
    name: "addemoji",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message, args) => {

        if (client.config.buyers.includes(message.authorId)) {
            if (!args.length) return message.channel.send({ content: "Veuillez spécifier l'émoji" })
            
            for (const rawEmoji of args) { 
                const parsedEmoji = parseEmoji(rawEmoji)
               
                if (parsedEmoji.id) {
                    const extension = parsedEmoji.animated ? ".gif" : ".png"
                    const url = `https://cdn.discordapp.com/emojis/${parsedEmoji.id + extension}`
                    message.guild.createEmoji({image: url, name: parsedEmoji.name})
                    .then((emoji) => message.channel.send(new Embed({
                        color: client.config.default_color,
                        fields: [{
                            name: "Emojis créés",
                            value: `<${emoji.animated?"a":""}:${emoji.name}:${emoji.id}>`,
                        
                        }, {
                            name: "ID",
                            value: `${parsedEmoji.id}`
                        }, {
                            name: "Nom",
                            value: `${parsedEmoji.name}`
                        }, {
                            name: "URL",
                            value: `${url}`
                        }, {
                            name: "Ajouté par",
                            value: `<@${message.authorId}>`
                        }],
                        image: "https://cdn.discordapp.com/emojis/" + parsedEmoji.id + extension,
                        footer: client.config.footer
                    })))
                }
            }
                }
            }
        }
 
