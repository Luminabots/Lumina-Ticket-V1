const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');
const {StringSelect, ActionRow} = require('devland.js')
module.exports = {
    name: "antilink",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message, args) => {
        if (client.config.buyers.includes(message.authorId)){
            const antilink = client.db.get(`antilink_${message.guildId}`);

            let config = new StringSelect()
            config.customId = "antilinkconf"
            config.addOptions({
                label: "Antilink all",
                description: "Defini l'antilink sur \`all\`",
                value: "antiall"
            }, {
                label: "Antilink web",
                description: "Defini l'antilink sur \`web\`",
                value: "antiweb"
            }, {
                label: "Antilink invite",
                description: "Defini l'antilink sur \`invite\`",
                value: "antiinv"
            })
            let row = new ActionRow(config)

            message.channel.send({components: [row]})

            
         
        }
    }
}

