const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');

module.exports = {
    name: "serverinfo",
    run: async(client, message) => {
        let guild = message.guild
    
        const filterLevels = {
            DISABLED: 'Off',
            MEMBERS_WITHOUT_ROLES: 'No Role',
            ALL_MEMBERS: 'Everyone'
        };
      
        const verifLevels = {
            NONE: 'None',
            LOW: 'Low',
            MEDIUM: 'Medium',
            HIGH: '(╯°□°）╯︵ ┻━┻',
            VERY_HIGH: '┻━┻ ﾐヽ(ಠ益ಠ)ノ彡┻━┻'
        };
        const serveri = new Discord.Embed();
        serveri.fields = [{
            name: "Nom du serveur:",
            value: guild.name
        }, {
            name: "Nombre de membres:",
            value: guild.members.size
        }, {
            name: "Nombre d'humains :",
            value: guild.members.filter(m => !m.user.bot).size
        }, {
            name: "Nombre de bots :",
            value: guild.members.filter(m => m.user.bot).size
        }, {
            name: "Nombre de boosters:",
            value: guild.members.filter(m => m.premium_since).size
        }, {
            name: "Nombre de boosts:",
            value: guild.boostCount
        }, {
            name: "Niveau de Boosts:",
            value: guild.boostLevel
        },{
            name: "Nombre de rôles:",
            value: guild.roles.size
        }]
        serveri.footer = client.config.footer
        message.reply(serveri)
    }
}