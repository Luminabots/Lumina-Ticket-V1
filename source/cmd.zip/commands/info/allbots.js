const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');

module.exports = {
    name: "allbots",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message) => {
        const botM = message.guild.members.filter(m => m.user.bot);
        const botId = botM.map(m => m.user.id);

        if (botId.length === 0) {
            const nobot = new Embed();
            nobot.title = "Liste Des Bots",
            nobot.color = client.config.default_color,
            nobot.footer = client.config.footer,
            nobot.description = "Aucun Bot"
        }

        const botN = botM.map(m => `[${m.user.tag}](https://discord.com/users/${m.user.id})`).join('\n');

        let boostE = new Discord.Embed()
        boostE.title = 'Liste Des Bots'
        boostE.description = `${botN}`,
        boostE.color = client.config.default_color,
        boostE.footer = client.config.footer
        message.reply({ embeds: [boostE], allowedMentions:{ repliedUser : false} });
    }
}
