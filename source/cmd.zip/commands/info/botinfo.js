const Discord = require('devland.js')
const {Embed} = require("devland.js")
module.exports = {
    name : "botinfo",

    run: async(client, message) => {
        
    const embed = new Embed()
    embed.title = client.user.username
    embed.fields = [{
        name: "🤖・Bot Informations:",
        value: `>>> Nom:<@${client.user.id}> | \`${client.user.tag}\`\nIdentifiant: ${client.user.id}\n`
    }, {
        name: ""
    }]
    embed.color = client.config.default_color
    embed.footer = client.config.footer
    message.channel.send(embed)
    }
}