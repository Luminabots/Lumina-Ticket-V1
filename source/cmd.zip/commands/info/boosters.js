const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');

module.exports = {
    name: "boosters",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message) => {
        const guild = message.guild;
        let desc = "";
        guild.members
        .filter((m) => m.premium_since)
        .forEach((m) => {
            desc += `[${m.user.tag}](https://discord.com/users/${m.user.id}) | \`${m.user.id}\`\n\n`
        })
     

        let boostE = new Discord.Embed()
        boostE.description = desc || "Ce serveur n'a aucun boost",
        boostE.color = client.config.default_color,
        boostE.footer = client.config.footer
        message.reply({ embeds: [boostE], allowedMentions: { repliedUser: false } });
    }
}
