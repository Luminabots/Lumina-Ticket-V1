const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');

module.exports = {
    name: "alladmin",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message) => {
        const admins = message.guild.members.filter(member => member.permissions.has("ADMINISTRATOR"))

        if (admins.size === 0) {
            return message.reply('Il n\'y a pas d\'administrateurs sur ce serveur.');
        }

        const adminNames = admins.map(admin => `[${admin.user.tag}](https://discord.com/users/${admin.user.id})`)

        let boostE = new Discord.Embed()
        boostE.title = 'Liste des administrateurs'
        boostE.description = adminNames.join('\n'),
        boostE.color = client.config.default_color,
        boostE.footer = client.config.footer
        message.reply({ embeds: [boostE], allowedMentions: { repliedUser: false } });
    }
}
