const Discord = require('devland.js');
const Lumina = require('../../structures/client/index');
md5 = require("md5");
module.exports = {
    name: "gay",
         /**
     * 
     * @param {Lumina} client 
     * @param {Discord.Message} message
     * @param {string[]} args 
     */
    run: async(client, message) => {
      
        const member = message.memberMentions.first() || message.member ;

         
        if(member.id === "1072553881134972970") {

           let noyou = new Discord.Embed()
           noyou.title = "Gay 🏳️‍🌈"
           noyou.description = `<@1072553881134972970> est gay à 0%!`
           noyou.color = client.config.default_color
           noyou.footer = client.config.footer
           

           message.channel.send(noyou)
        }
        else {
            const hash = md5(
                `${member.id}${member.user.username}`
            );

            const string = hash 
            .split("")
            .filter(e => !isNaN(e))
            .join("");
            const percent = parseInt(string.substr(0, 2), 10);

            const embed = new Discord.Embed()
            embed.title = "Gay 🏳️‍🌈"
            embed.description = `${member.user.username} est gay à ${percent}%`
            embed.color = client.config.default_color
            embed.footer = client.config.footer

            message.channel.send(embed)
        }


    }
}
